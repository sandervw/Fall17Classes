import math

r = 3.2
h = 6.1

vol = math.pi * r**2 * h

print vol
